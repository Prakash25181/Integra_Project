import React, { useState, useContext } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, ScrollView, Switch, TextInput, Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { AppContext } from '../App';
import { Colors, Radius } from '../theme';
import { Commands } from '../connection';

function Card({ title, children }) {
  return (
    <View style={styles.card}>
      <View style={styles.cardHeader}>
        <Text style={styles.cardTitle}>{title}</Text>
      </View>
      <View style={styles.cardBody}>{children}</View>
    </View>
  );
}

function Row({ label, value, valueColor, children }) {
  return (
    <View style={styles.row}>
      <Text style={styles.rowLabel}>{label}</Text>
      {children || (
        <Text style={[styles.rowValue, valueColor && { color: valueColor }]}>{value}</Text>
      )}
    </View>
  );
}

export default function DeviceScreen() {
  const { deviceInfo, playerState, sendCommand, connected, connect, disconnect } = useContext(AppContext);
  const [hdmiCec, setHdmiCec] = useState(true);
  const [autoPower, setAutoPower] = useState(true);
  const [netStandby, setNetStandby] = useState(false);
  const [muting, setMuting] = useState(false);
  const [inputIp, setInputIp] = useState('');
  const [showConnect, setShowConnect] = useState(!connected);

  const handleConnect = () => {
    if (inputIp.trim()) {
      connect(inputIp.trim());
      setShowConnect(false);
    } else {
      Alert.alert('IP Address', 'Please enter receiver IP address');
    }
  };

  const handleDisconnect = () => {
    Alert.alert(
      'Disconnect',
      'Disconnect from receiver?',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Disconnect', style: 'destructive', onPress: disconnect },
      ]
    );
  };

  const handlePower = () => {
    if (connected) {
      Alert.alert(
        'Power',
        'Turn off receiver?',
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Power Off', style: 'destructive', onPress: () => sendCommand(Commands.POWER_OFF) },
        ]
      );
    }
  };

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
      showsVerticalScrollIndicator={false}
    >
      {/* Connection Status */}
      <View style={[styles.statusBanner, connected ? styles.statusBannerConnected : styles.statusBannerDisconnected]}>
        <View style={styles.statusBannerLeft}>
          <View style={[styles.statusDot, connected ? styles.dotGreen : styles.dotRed]} />
          <Text style={styles.statusBannerText}>
            {connected ? `Connected — ${deviceInfo.ip || '192.168.1.42'}` : 'Not Connected'}
          </Text>
        </View>
        <TouchableOpacity
          style={styles.statusBannerBtn}
          onPress={connected ? handleDisconnect : () => setShowConnect(true)}
        >
          <Text style={styles.statusBannerBtnText}>{connected ? 'Disconnect' : 'Connect'}</Text>
        </TouchableOpacity>
      </View>

      {/* Connect Form */}
      {(!connected || showConnect) && (
        <Card title="Connect to Receiver">
          <View style={styles.connectForm}>
            <View style={styles.ipInput}>
              <Ionicons name="wifi" size={16} color={Colors.text3} />
              <TextInput
                style={styles.ipField}
                placeholder="192.168.1.xxx"
                placeholderTextColor={Colors.text3}
                value={inputIp}
                onChangeText={setInputIp}
                keyboardType="numeric"
                returnKeyType="connect"
                onSubmitEditing={handleConnect}
              />
            </View>
            <TouchableOpacity style={styles.connectBtn} onPress={handleConnect}>
              <Text style={styles.connectBtnText}>Connect</Text>
            </TouchableOpacity>
          </View>
          <Text style={styles.connectHint}>
            Make sure your phone and receiver are on the same Wi-Fi network. Default port: 60128.
          </Text>
        </Card>
      )}

      {/* Device Info */}
      <Card title="Receiver Info">
        <Row label="Device Name" value={deviceInfo.name || 'TX-NR7100'} />
        <Row label="Model" value={deviceInfo.model || 'TX-NR7100'} />
        <Row label="Brand" value={deviceInfo.brand || 'Onkyo'} />
        <Row label="Zone" value={deviceInfo.zone || 'Zone 1'} valueColor={Colors.accent2} />
        <Row label="IP Address" value={deviceInfo.ip || '---'} />
        <Row label="Port" value={String(deviceInfo.port || 60128)} />
        <Row label="Firmware" value={deviceInfo.firmware || '---'} valueColor={Colors.green} />
      </Card>

      {/* Audio Info */}
      <Card title="Audio Info">
        <Row label="Input Format" value={playerState.format || 'FLAC 24bit/96kHz'} />
        <Row label="Output Format" value="PCM 24bit/96kHz" />
        <Row label="Channels" value="2.0 Stereo" />
        <Row label="Listening Mode" value={playerState.listeningMode || 'Stereo'} />
        <Row label="Input Selector" value={playerState.inputSelector || 'NET'} />
      </Card>

      {/* Settings */}
      <Card title="Settings">
        <Row label="Auto Power On">
          <Switch
            value={autoPower}
            onValueChange={setAutoPower}
            trackColor={{ false: Colors.bg4, true: Colors.accent }}
            thumbColor={Colors.white}
          />
        </Row>
        <Row label="HDMI CEC">
          <Switch
            value={hdmiCec}
            onValueChange={setHdmiCec}
            trackColor={{ false: Colors.bg4, true: Colors.accent }}
            thumbColor={Colors.white}
          />
        </Row>
        <Row label="Network Standby">
          <Switch
            value={netStandby}
            onValueChange={setNetStandby}
            trackColor={{ false: Colors.bg4, true: Colors.accent }}
            thumbColor={Colors.white}
          />
        </Row>
        <Row label="Audio Muting">
          <Switch
            value={muting}
            onValueChange={(val) => {
              setMuting(val);
              sendCommand(val ? Commands.MUTE_ON : Commands.MUTE_OFF);
            }}
            trackColor={{ false: Colors.bg4, true: Colors.red }}
            thumbColor={Colors.white}
          />
        </Row>
      </Card>

      {/* Power Control */}
      <Card title="Power Control">
        <TouchableOpacity
          style={[styles.powerBtn, !connected && styles.powerBtnDisabled]}
          onPress={handlePower}
          disabled={!connected}
        >
          <Ionicons name="power" size={18} color={connected ? Colors.red : Colors.text3} />
          <Text style={[styles.powerBtnText, !connected && { color: Colors.text3 }]}>
            Power Off Receiver
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.powerBtnAlt}
          onPress={() => sendCommand(Commands.POWER_ON)}
          disabled={!connected}
        >
          <Ionicons name="power" size={18} color={connected ? Colors.green : Colors.text3} />
          <Text style={[styles.powerBtnAltText, !connected && { color: Colors.text3 }]}>
            Power On Receiver
          </Text>
        </TouchableOpacity>
      </Card>

      <View style={{ height: 20 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  content: { padding: 20, gap: 12 },

  statusBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 14,
    borderRadius: Radius.md,
    marginBottom: 4,
    borderWidth: 0.5,
  },
  statusBannerConnected: {
    backgroundColor: 'rgba(74,222,128,0.08)',
    borderColor: 'rgba(74,222,128,0.25)',
  },
  statusBannerDisconnected: {
    backgroundColor: 'rgba(255,92,92,0.08)',
    borderColor: 'rgba(255,92,92,0.25)',
  },
  statusBannerLeft: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  statusDot: { width: 8, height: 8, borderRadius: 4 },
  dotGreen: { backgroundColor: Colors.green },
  dotRed: { backgroundColor: Colors.red },
  statusBannerText: { fontSize: 13, color: Colors.text2, fontWeight: '500' },
  statusBannerBtn: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: Radius.sm,
    backgroundColor: Colors.bg3,
    borderWidth: 0.5,
    borderColor: Colors.border,
  },
  statusBannerBtnText: { fontSize: 12, color: Colors.text2, fontWeight: '500' },

  card: {
    backgroundColor: Colors.bg3,
    borderRadius: Radius.md,
    borderWidth: 0.5,
    borderColor: Colors.border,
    overflow: 'hidden',
  },
  cardHeader: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 0.5,
    borderBottomColor: Colors.border,
  },
  cardTitle: { fontSize: 13, fontWeight: '500', color: Colors.text2 },
  cardBody: {},
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 0.5,
    borderBottomColor: Colors.border,
  },
  rowLabel: { fontSize: 13, color: Colors.text3 },
  rowValue: { fontSize: 13, color: Colors.text1, fontWeight: '500', maxWidth: '55%', textAlign: 'right' },

  connectForm: { flexDirection: 'row', gap: 10, padding: 16, paddingBottom: 8 },
  ipInput: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: Colors.bg4,
    borderRadius: Radius.sm,
    paddingHorizontal: 12,
    borderWidth: 0.5,
    borderColor: Colors.border,
  },
  ipField: { flex: 1, height: 40, fontSize: 14, color: Colors.text1 },
  connectBtn: {
    backgroundColor: Colors.accent,
    borderRadius: Radius.sm,
    paddingHorizontal: 16,
    alignItems: 'center',
    justifyContent: 'center',
    height: 40,
  },
  connectBtnText: { fontSize: 13, fontWeight: '600', color: Colors.white },
  connectHint: { fontSize: 12, color: Colors.text3, padding: 16, paddingTop: 4, lineHeight: 18 },

  powerBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    margin: 12,
    padding: 14,
    borderRadius: Radius.sm,
    backgroundColor: 'rgba(255,92,92,0.1)',
    borderWidth: 0.5,
    borderColor: 'rgba(255,92,92,0.25)',
  },
  powerBtnDisabled: { opacity: 0.4 },
  powerBtnText: { fontSize: 14, fontWeight: '500', color: Colors.red },
  powerBtnAlt: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginHorizontal: 12,
    marginBottom: 12,
    padding: 14,
    borderRadius: Radius.sm,
    backgroundColor: 'rgba(74,222,128,0.08)',
    borderWidth: 0.5,
    borderColor: 'rgba(74,222,128,0.2)',
  },
  powerBtnAltText: { fontSize: 14, fontWeight: '500', color: Colors.green },
});
