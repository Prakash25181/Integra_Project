import React, { useState, useContext } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, ScrollView,
} from 'react-native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { AppContext } from '../App';
import { Colors, Radius } from '../theme';
import { Commands } from '../connection';

const LISTENING_MODES = [
  { label: 'Stereo', code: 'STEREO' },
  { label: 'Direct', code: 'DIRECT' },
  { label: 'Pure Audio', code: 'PURE_AUDIO' },
  { label: 'Dolby Atmos', code: '0F' },
  { label: 'DTS:X', code: '10' },
  { label: 'All Ch Stereo', code: 'ALL_CH_STEREO' },
  { label: 'Orchestra', code: 'ORCHESTRA' },
  { label: 'Theater-D', code: 'THEATER_D' },
];

function RemBtn({ icon, label, onPress, accent, wide, style }) {
  return (
    <TouchableOpacity
      style={[
        wide ? styles.wideBtn : styles.remBtn,
        accent && styles.remBtnAccent,
        style,
      ]}
      onPress={onPress}
      activeOpacity={0.65}
    >
      {icon && (
        <Ionicons
          name={icon}
          size={wide ? 16 : 22}
          color={accent ? Colors.accent2 : Colors.text2}
          style={wide ? { marginRight: 6 } : { marginBottom: label ? 4 : 0 }}
        />
      )}
      {label && (
        <Text style={[styles.remBtnLabel, accent && { color: Colors.accent2 }, wide && styles.wideBtnLabel]}>
          {label}
        </Text>
      )}
    </TouchableOpacity>
  );
}

export default function RemoteScreen() {
  const { playerState, sendCommand, setListeningMode, connected } = useContext(AppContext);
  const [feedback, setFeedback] = useState('');

  const send = (cmd, label) => {
    sendCommand(cmd);
    setFeedback(`Sent: ${label}`);
    setTimeout(() => setFeedback(''), 1500);
  };

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.header}>
        <Text style={styles.title}>OSD Remote</Text>
        <Text style={styles.subtitle}>{playerState.inputSelector || 'NET'} · Zone 1</Text>
      </View>

      {/* Top action buttons */}
      <View style={styles.topRow}>
        <RemBtn wide icon="settings-outline" label="Setup" onPress={() => send(Commands.OSD_MENU, 'Setup')} />
        <RemBtn wide icon="home-outline" label="Home" onPress={() => send(Commands.OSD_HOME, 'Home')} />
        <RemBtn wide icon="menu-outline" label="Quick" onPress={() => send(Commands.OSD_QUICK, 'Quick Menu')} />
      </View>

      {/* D-Pad */}
      <View style={styles.dpad}>
        {/* Up */}
        <View style={styles.dpadRow}>
          <RemBtn
            icon="chevron-up"
            onPress={() => send(Commands.OSD_UP, 'Up')}
            style={styles.dpadBtn}
          />
        </View>
        {/* Left + OK + Right */}
        <View style={[styles.dpadRow, { gap: 10 }]}>
          <RemBtn
            icon="chevron-back"
            onPress={() => send(Commands.OSD_LEFT, 'Left')}
            style={styles.dpadBtn}
          />
          <TouchableOpacity
            style={styles.okBtn}
            onPress={() => send(Commands.OSD_ENTER, 'Enter')}
            activeOpacity={0.7}
          >
            <View style={styles.okInner} />
            <Text style={styles.okText}>OK</Text>
          </TouchableOpacity>
          <RemBtn
            icon="chevron-forward"
            onPress={() => send(Commands.OSD_RIGHT, 'Right')}
            style={styles.dpadBtn}
          />
        </View>
        {/* Down */}
        <View style={styles.dpadRow}>
          <RemBtn
            icon="chevron-down"
            onPress={() => send(Commands.OSD_DOWN, 'Down')}
            style={styles.dpadBtn}
          />
        </View>
      </View>

      {/* Return + Menu */}
      <View style={styles.bottomRow}>
        <RemBtn wide icon="return-down-back-outline" label="Return" onPress={() => send(Commands.OSD_EXIT, 'Return')} />
        <RemBtn wide icon="grid-outline" label="Menu" onPress={() => send('MNMEN', 'Menu')} />
      </View>

      {/* Divider */}
      <View style={styles.divider} />

      {/* Feedback */}
      {feedback ? (
        <Text style={styles.feedback}>{feedback}</Text>
      ) : null}

      {/* Listening Modes */}
      <Text style={styles.sectionLabel}>Listening Mode</Text>
      <View style={styles.listenModes}>
        {LISTENING_MODES.map((mode) => (
          <TouchableOpacity
            key={mode.code}
            style={[
              styles.modeChip,
              playerState.listeningMode === mode.label && styles.modeChipActive,
            ]}
            onPress={() => {
              setListeningMode(mode.label);
              setFeedback(`Mode: ${mode.label}`);
              setTimeout(() => setFeedback(''), 1500);
            }}
          >
            <Text style={[
              styles.modeText,
              playerState.listeningMode === mode.label && styles.modeTextActive,
            ]}>
              {mode.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Divider */}
      <View style={styles.divider} />

      {/* CD Player Controls */}
      <Text style={styles.sectionLabel}>CD / BD Controls</Text>
      <View style={styles.cdRow}>
        {[
          { icon: 'play-skip-back', cmd: 'NTCTRDN', label: 'Prev' },
          { icon: 'stop', cmd: 'NTCSTOP', label: 'Stop' },
          { icon: 'play', cmd: 'NTCPLAY', label: 'Play' },
          { icon: 'pause', cmd: 'NTCPAUSE', label: 'Pause' },
          { icon: 'play-skip-forward', cmd: 'NTCTRUP', label: 'Next' },
        ].map((btn) => (
          <TouchableOpacity
            key={btn.cmd}
            style={styles.cdBtn}
            onPress={() => send(btn.cmd, btn.label)}
            activeOpacity={0.7}
          >
            <Ionicons name={btn.icon} size={20} color={Colors.text2} />
            <Text style={styles.cdBtnLabel}>{btn.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <View style={{ height: 20 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  content: { padding: 20 },

  header: { alignItems: 'center', marginBottom: 20 },
  title: { fontSize: 18, fontWeight: '700', color: Colors.text1 },
  subtitle: { fontSize: 12, color: Colors.text3, marginTop: 3 },

  topRow: { flexDirection: 'row', gap: 8, marginBottom: 20 },
  wideBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    borderRadius: Radius.sm,
    backgroundColor: Colors.card,
    borderWidth: 0.5,
    borderColor: Colors.border,
  },
  wideBtnLabel: { fontSize: 12, color: Colors.text2, fontWeight: '500' },

  dpad: { alignItems: 'center', marginBottom: 16, gap: 8 },
  dpadRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  dpadBtn: {
    width: 72, height: 72,
    borderRadius: 16,
    backgroundColor: Colors.card,
    borderWidth: 0.5,
    borderColor: Colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  remBtn: {
    width: 72, height: 72,
    borderRadius: 14,
    backgroundColor: Colors.card,
    borderWidth: 0.5,
    borderColor: Colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  remBtnAccent: {
    backgroundColor: 'rgba(108,99,255,0.2)',
    borderColor: 'rgba(108,99,255,0.4)',
  },
  remBtnLabel: { fontSize: 10, fontWeight: '500', color: Colors.text2, textAlign: 'center' },

  okBtn: {
    width: 80, height: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(108,99,255,0.2)',
    borderWidth: 0.5,
    borderColor: 'rgba(108,99,255,0.5)',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  okInner: {
    width: 32, height: 32,
    borderRadius: 16,
    backgroundColor: Colors.accent,
    position: 'absolute',
  },
  okText: {
    fontSize: 13,
    fontWeight: '700',
    color: Colors.white,
    zIndex: 1,
  },

  bottomRow: { flexDirection: 'row', gap: 8, marginBottom: 12 },

  feedback: {
    textAlign: 'center',
    fontSize: 12,
    color: Colors.accent2,
    marginBottom: 8,
    minHeight: 18,
  },

  divider: { height: 0.5, backgroundColor: Colors.border, marginVertical: 16 },

  sectionLabel: {
    fontSize: 11,
    fontWeight: '500',
    color: Colors.text3,
    textTransform: 'uppercase',
    letterSpacing: 1,
    marginBottom: 12,
  },

  listenModes: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 4 },
  modeChip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: Radius.full,
    backgroundColor: Colors.card,
    borderWidth: 0.5,
    borderColor: Colors.border,
  },
  modeChipActive: {
    backgroundColor: 'rgba(108,99,255,0.2)',
    borderColor: 'rgba(108,99,255,0.5)',
  },
  modeText: { fontSize: 12, fontWeight: '500', color: Colors.text3 },
  modeTextActive: { color: Colors.accent2 },

  cdRow: { flexDirection: 'row', justifyContent: 'space-between', gap: 6 },
  cdBtn: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: Radius.sm,
    backgroundColor: Colors.card,
    borderWidth: 0.5,
    borderColor: Colors.border,
    alignItems: 'center',
    gap: 5,
  },
  cdBtnLabel: { fontSize: 9, color: Colors.text3, fontWeight: '500' },
});
