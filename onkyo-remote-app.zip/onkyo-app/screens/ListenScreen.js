import React, { useState, useContext } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, TouchableHighlight,
  ScrollView, Dimensions, StatusBar, Image,
} from 'react-native';
import { Ionicons, MaterialIcons, MaterialCommunityIcons } from '@expo/vector-icons';
import Slider from '@react-native-community/slider';
import { AppContext } from '../App';
import { Colors, Radius } from '../theme';
import { Commands } from '../connection';

const { width } = Dimensions.get('window');
const COVER_SIZE = width - 48;

const INPUT_SOURCES = [
  { label: 'NET', code: 'NET', icon: 'wifi' },
  { label: 'Bluetooth', code: 'BLUETOOTH', icon: 'bluetooth' },
  { label: 'HDMI 1', code: 'HDMI1', icon: 'tv' },
  { label: 'HDMI 2', code: 'HDMI2', icon: 'tv' },
  { label: 'CD', code: 'CD', icon: 'album' },
  { label: 'Phono', code: 'PHONO', icon: 'vinyl' },
  { label: 'TV/CD', code: 'TV_CD', icon: 'musical-notes' },
  { label: 'AUX', code: 'VIDEO1', icon: 'headset' },
  { label: 'Tuner', code: 'TUNER', icon: 'radio' },
];

export default function ListenScreen() {
  const { playerState, sendCommand, setVolume, setInput, connected } = useContext(AppContext);

  const handlePlayPause = () => {
    if (playerState.isPlaying) {
      sendCommand(Commands.PAUSE);
    } else {
      sendCommand(Commands.PLAY);
    }
  };

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.scrollContent}
      showsVerticalScrollIndicator={false}
    >
      {/* Album Cover */}
      <View style={styles.coverWrap}>
        <View style={styles.cover}>
          <View style={styles.coverGradient} />
          <Ionicons name="musical-notes" size={80} color={Colors.accent2} style={{ opacity: 0.9 }} />
          {playerState.format ? (
            <View style={styles.coverBadge}>
              <Text style={styles.coverBadgeText}>{playerState.format.split('/')[0]}</Text>
            </View>
          ) : null}
          <View style={styles.coverSource}>
            <Ionicons name="wifi" size={11} color={Colors.text2} />
            <Text style={styles.coverSourceText}>
              {playerState.inputSelector || 'NET'}
            </Text>
          </View>
        </View>
      </View>

      {/* Track Info */}
      <View style={styles.trackInfo}>
        <Text style={styles.trackTitle} numberOfLines={1}>
          {playerState.title || '---'}
        </Text>
        <Text style={styles.trackArtist} numberOfLines={1}>
          {playerState.artist || '---'}
        </Text>
        <Text style={styles.trackAlbum} numberOfLines={1}>
          {playerState.album || '---'}
        </Text>
      </View>

      {/* Action Buttons */}
      <View style={styles.actionsRow}>
        <TouchableOpacity style={styles.actionBtn}>
          <Ionicons name="heart" size={20} color={Colors.accent2} />
          <Text style={styles.actionLabel}>Like</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.actionBtn}>
          <Ionicons name="share-social-outline" size={20} color={Colors.text3} />
          <Text style={styles.actionLabel}>Share</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.actionBtn}>
          <Ionicons name="list-outline" size={20} color={Colors.text3} />
          <Text style={styles.actionLabel}>Queue</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.actionBtn}>
          <Ionicons name="ellipsis-horizontal" size={20} color={Colors.text3} />
          <Text style={styles.actionLabel}>More</Text>
        </TouchableOpacity>
      </View>

      {/* Progress Bar */}
      <View style={styles.progressWrap}>
        <Slider
          style={styles.slider}
          minimumValue={0}
          maximumValue={100}
          value={playerState.progress || 0}
          minimumTrackTintColor={Colors.accent}
          maximumTrackTintColor={Colors.bg4}
          thumbTintColor={Colors.white}
          onValueChange={(val) => {}}
        />
        <View style={styles.progressTimes}>
          <Text style={styles.timeText}>{playerState.timeElapsed || '0:00'}</Text>
          <Text style={styles.timeText}>{playerState.timeTotal || '0:00'}</Text>
        </View>
      </View>

      {/* Playback Controls */}
      <View style={styles.controls}>
        <TouchableOpacity
          style={[styles.ctrlBtn, playerState.repeat && styles.ctrlBtnActive]}
          onPress={() => sendCommand(Commands.REPEAT)}
        >
          <Ionicons
            name="repeat"
            size={22}
            color={playerState.repeat ? Colors.accent2 : Colors.text3}
          />
        </TouchableOpacity>

        <TouchableOpacity style={styles.ctrlBtn} onPress={() => sendCommand(Commands.TRACK_DOWN)}>
          <Ionicons name="play-skip-back" size={26} color={Colors.text2} />
        </TouchableOpacity>

        <TouchableOpacity style={styles.playBtn} onPress={handlePlayPause}>
          <Ionicons
            name={playerState.isPlaying ? 'pause' : 'play'}
            size={28}
            color={Colors.white}
            style={!playerState.isPlaying ? { marginLeft: 3 } : {}}
          />
        </TouchableOpacity>

        <TouchableOpacity style={styles.ctrlBtn} onPress={() => sendCommand(Commands.TRACK_UP)}>
          <Ionicons name="play-skip-forward" size={26} color={Colors.text2} />
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.ctrlBtn, playerState.shuffle && styles.ctrlBtnActive]}
          onPress={() => sendCommand(Commands.RANDOM)}
        >
          <Ionicons
            name="shuffle"
            size={22}
            color={playerState.shuffle ? Colors.accent2 : Colors.text3}
          />
        </TouchableOpacity>
      </View>

      {/* Volume */}
      <View style={styles.volumeRow}>
        <Ionicons name="volume-low" size={18} color={Colors.text3} />
        <Slider
          style={styles.volSlider}
          minimumValue={0}
          maximumValue={100}
          value={playerState.volume || 40}
          minimumTrackTintColor={Colors.accent}
          maximumTrackTintColor={Colors.bg4}
          thumbTintColor={Colors.text2}
          onValueChange={(val) => setVolume(val)}
        />
        <Ionicons name="volume-high" size={18} color={Colors.text3} />
        <View style={styles.volBadge}>
          <Text style={styles.volText}>{Math.round(playerState.volume || 0)}</Text>
        </View>
      </View>

      {/* Mute Button */}
      <TouchableOpacity
        style={[styles.muteBtn, playerState.muted && styles.muteBtnActive]}
        onPress={() => sendCommand(Commands.MUTE_TOGGLE)}
      >
        <Ionicons
          name={playerState.muted ? 'volume-mute' : 'volume-medium'}
          size={16}
          color={playerState.muted ? Colors.red : Colors.text2}
        />
        <Text style={[styles.muteBtnText, playerState.muted && { color: Colors.red }]}>
          {playerState.muted ? 'Muted' : 'Mute'}
        </Text>
      </TouchableOpacity>

      {/* Input Source */}
      <Text style={styles.sectionLabel}>Input Source</Text>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.chipsScroll}
        contentContainerStyle={styles.chipsContent}
      >
        {INPUT_SOURCES.map((src) => (
          <TouchableOpacity
            key={src.code}
            style={[
              styles.chip,
              playerState.inputSelector === src.label && styles.chipActive,
            ]}
            onPress={() => setInput(src.code)}
          >
            <Text
              style={[
                styles.chipText,
                playerState.inputSelector === src.label && styles.chipTextActive,
              ]}
            >
              {src.label}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <View style={{ height: 20 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  scrollContent: { padding: 24 },

  coverWrap: { marginBottom: 24 },
  cover: {
    width: COVER_SIZE,
    height: COVER_SIZE,
    borderRadius: 24,
    backgroundColor: '#1e1040',
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    position: 'relative',
  },
  coverGradient: {
    position: 'absolute',
    inset: 0,
    top: 0, bottom: 0, left: 0, right: 0,
    backgroundColor: 'transparent',
  },
  coverBadge: {
    position: 'absolute',
    top: 14, right: 14,
    backgroundColor: 'rgba(0,0,0,0.55)',
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderWidth: 0.5,
    borderColor: 'rgba(108,99,255,0.35)',
  },
  coverBadgeText: { fontSize: 11, fontWeight: '500', color: Colors.accent2 },
  coverSource: {
    position: 'absolute',
    bottom: 14, left: 14,
    backgroundColor: 'rgba(0,0,0,0.55)',
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 5,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    borderWidth: 0.5,
    borderColor: Colors.border,
  },
  coverSourceText: { fontSize: 11, color: Colors.text2, marginLeft: 5 },

  trackInfo: { alignItems: 'center', marginBottom: 16 },
  trackTitle: { fontSize: 22, fontWeight: '700', color: Colors.text1, marginBottom: 4, textAlign: 'center' },
  trackArtist: { fontSize: 15, color: Colors.text2, textAlign: 'center' },
  trackAlbum: { fontSize: 13, color: Colors.text3, marginTop: 2, textAlign: 'center' },

  actionsRow: { flexDirection: 'row', justifyContent: 'space-around', marginBottom: 20 },
  actionBtn: { alignItems: 'center', gap: 4 },
  actionLabel: { fontSize: 10, color: Colors.text3, marginTop: 4 },

  progressWrap: { marginBottom: 20 },
  slider: { width: '100%', height: 40 },
  progressTimes: { flexDirection: 'row', justifyContent: 'space-between', marginTop: -8 },
  timeText: { fontSize: 11, color: Colors.text3 },

  controls: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 10,
    marginBottom: 24,
  },
  ctrlBtn: { padding: 8, borderRadius: Radius.sm },
  ctrlBtnActive: { backgroundColor: 'rgba(108,99,255,0.15)' },
  playBtn: {
    width: 64, height: 64,
    borderRadius: 32,
    backgroundColor: Colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: Colors.accent,
    shadowOpacity: 0.5,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 4 },
    elevation: 8,
  },

  volumeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    gap: 8,
  },
  volSlider: { flex: 1, height: 40 },
  volBadge: {
    backgroundColor: Colors.bg3,
    borderRadius: Radius.sm,
    paddingHorizontal: 8,
    paddingVertical: 4,
    minWidth: 36,
    alignItems: 'center',
  },
  volText: { fontSize: 12, color: Colors.text2, fontWeight: '500' },

  muteBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'center',
    gap: 6,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: Radius.full,
    backgroundColor: Colors.card,
    borderWidth: 0.5,
    borderColor: Colors.border,
    marginBottom: 24,
  },
  muteBtnActive: { borderColor: Colors.red, backgroundColor: 'rgba(255,92,92,0.1)' },
  muteBtnText: { fontSize: 13, color: Colors.text2, fontWeight: '500' },

  sectionLabel: {
    fontSize: 11,
    fontWeight: '500',
    color: Colors.text3,
    textTransform: 'uppercase',
    letterSpacing: 1,
    marginBottom: 10,
  },
  chipsScroll: { marginBottom: 0 },
  chipsContent: { gap: 8, paddingRight: 8 },
  chip: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: Radius.full,
    backgroundColor: Colors.card,
    borderWidth: 0.5,
    borderColor: Colors.border,
  },
  chipActive: {
    backgroundColor: 'rgba(108,99,255,0.25)',
    borderColor: 'rgba(108,99,255,0.5)',
  },
  chipText: { fontSize: 12, fontWeight: '500', color: Colors.text2 },
  chipTextActive: { color: Colors.accent2 },
});
