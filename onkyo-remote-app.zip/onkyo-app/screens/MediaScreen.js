import React, { useState, useContext } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, FlatList,
  TextInput, Animated,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { AppContext } from '../App';
import { Colors, Radius } from '../theme';

const DEMO_TRACKS = [
  { id: '1', title: 'Midnight Serenade', artist: 'Norah Jones', album: 'Come Away With Me', duration: '3:42', color: '#1e1040', playing: true },
  { id: '2', title: 'Sunrise Boulevard', artist: 'Miles Davis', album: 'Kind of Blue', duration: '4:15', color: '#0a2a1a', playing: false },
  { id: '3', title: 'Velvet Underground', artist: 'Lou Reed', album: 'Velvet Underground', duration: '5:02', color: '#2a0a0a', playing: false },
  { id: '4', title: 'Golden Hour', artist: 'Kacey Musgraves', album: 'Golden Hour', duration: '3:47', color: '#2a1a0a', playing: false },
  { id: '5', title: 'Blue in Green', artist: 'Miles Davis', album: 'Kind of Blue', duration: '5:37', color: '#0a1a2a', playing: false },
  { id: '6', title: 'Come Away With Me', artist: 'Norah Jones', album: 'Come Away With Me', duration: '3:18', color: '#1a0a2a', playing: false },
  { id: '7', title: 'So What', artist: 'Miles Davis', album: 'Kind of Blue', duration: '9:22', color: '#0a2a1a', playing: false },
];

const NET_SERVICES = [
  { id: 'spotify', name: 'Spotify', icon: 'musical-note' },
  { id: 'tidal', name: 'Tidal', icon: 'water' },
  { id: 'tunein', name: 'TuneIn', icon: 'radio' },
  { id: 'dlna', name: 'DLNA / USB', icon: 'folder-open' },
  { id: 'pandora', name: 'Pandora', icon: 'star' },
  { id: 'deezer', name: 'Deezer', icon: 'disc' },
];

function PlayingBars() {
  return (
    <View style={styles.playingBars}>
      {[0, 1, 2].map((i) => (
        <View key={i} style={[styles.bar, { animationDelay: `${i * 0.1}s` }]} />
      ))}
    </View>
  );
}

export default function MediaScreen() {
  const { playerState, sendCommand, connected } = useContext(AppContext);
  const [search, setSearch] = useState('');
  const [activeTab, setActiveTab] = useState('queue');
  const [tracks, setTracks] = useState(DEMO_TRACKS);

  const filtered = tracks.filter(t =>
    t.title.toLowerCase().includes(search.toLowerCase()) ||
    t.artist.toLowerCase().includes(search.toLowerCase())
  );

  const playTrack = (item) => {
    setTracks(prev => prev.map(t => ({ ...t, playing: t.id === item.id })));
  };

  const renderTrack = ({ item }) => (
    <TouchableOpacity
      style={[styles.mediaItem, item.playing && styles.mediaItemPlaying]}
      onPress={() => playTrack(item)}
      activeOpacity={0.7}
    >
      <View style={[styles.thumb, { backgroundColor: item.color }]}>
        <Ionicons name="musical-notes" size={18} color="rgba(255,255,255,0.7)" />
      </View>
      <View style={styles.mediaMeta}>
        <Text style={[styles.mediaTitle, item.playing && { color: Colors.accent2 }]} numberOfLines={1}>
          {item.title}
        </Text>
        <Text style={styles.mediaSub} numberOfLines={1}>{item.artist}</Text>
      </View>
      <View style={styles.mediaRight}>
        {item.playing ? (
          <View style={styles.playingBars}>
            <View style={[styles.bar, styles.barAnim1]} />
            <View style={[styles.bar, styles.barAnim2]} />
            <View style={[styles.bar, styles.barAnim3]} />
          </View>
        ) : (
          <Text style={styles.duration}>{item.duration}</Text>
        )}
      </View>
    </TouchableOpacity>
  );

  const renderService = ({ item }) => (
    <TouchableOpacity style={styles.serviceItem} activeOpacity={0.7}>
      <View style={styles.serviceIcon}>
        <Ionicons name={item.icon} size={22} color={Colors.accent2} />
      </View>
      <Text style={styles.serviceName}>{item.name}</Text>
      <Ionicons name="chevron-forward" size={16} color={Colors.text3} />
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      {/* Search */}
      <View style={styles.searchBar}>
        <Ionicons name="search" size={16} color={Colors.text3} />
        <TextInput
          style={styles.searchInput}
          placeholder="Search tracks, albums, artists..."
          placeholderTextColor={Colors.text3}
          value={search}
          onChangeText={setSearch}
          returnKeyType="search"
        />
        {search.length > 0 && (
          <TouchableOpacity onPress={() => setSearch('')}>
            <Ionicons name="close-circle" size={16} color={Colors.text3} />
          </TouchableOpacity>
        )}
      </View>

      {/* Sub tabs */}
      <View style={styles.subTabs}>
        {['queue', 'services', 'presets'].map((tab) => (
          <TouchableOpacity
            key={tab}
            style={[styles.subTab, activeTab === tab && styles.subTabActive]}
            onPress={() => setActiveTab(tab)}
          >
            <Text style={[styles.subTabText, activeTab === tab && styles.subTabTextActive]}>
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {activeTab === 'queue' && (
        <FlatList
          data={filtered}
          keyExtractor={item => item.id}
          renderItem={renderTrack}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          ListHeaderComponent={
            <Text style={styles.sectionLabel}>Now Playing Queue</Text>
          }
        />
      )}

      {activeTab === 'services' && (
        <FlatList
          data={NET_SERVICES}
          keyExtractor={item => item.id}
          renderItem={renderService}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          ListHeaderComponent={
            <Text style={styles.sectionLabel}>Network Services</Text>
          }
        />
      )}

      {activeTab === 'presets' && (
        <View style={styles.emptyState}>
          <Ionicons name="bookmark-outline" size={40} color={Colors.text3} />
          <Text style={styles.emptyText}>No presets saved</Text>
          <Text style={styles.emptySubText}>Hold a track to save as preset</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg, padding: 20 },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.bg3,
    borderRadius: Radius.sm,
    paddingHorizontal: 14,
    paddingVertical: 10,
    marginBottom: 16,
    borderWidth: 0.5,
    borderColor: Colors.border,
    gap: 10,
  },
  searchInput: {
    flex: 1,
    fontSize: 14,
    color: Colors.text1,
    fontFamily: 'System',
  },
  subTabs: { flexDirection: 'row', gap: 8, marginBottom: 16 },
  subTab: {
    paddingHorizontal: 16,
    paddingVertical: 7,
    borderRadius: Radius.full,
    backgroundColor: Colors.card,
    borderWidth: 0.5,
    borderColor: Colors.border,
  },
  subTabActive: {
    backgroundColor: 'rgba(108,99,255,0.2)',
    borderColor: 'rgba(108,99,255,0.4)',
  },
  subTabText: { fontSize: 13, fontWeight: '500', color: Colors.text3 },
  subTabTextActive: { color: Colors.accent2 },
  sectionLabel: {
    fontSize: 11,
    fontWeight: '500',
    color: Colors.text3,
    textTransform: 'uppercase',
    letterSpacing: 1,
    marginBottom: 12,
  },
  listContent: { paddingBottom: 20 },

  mediaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: Radius.sm,
    marginBottom: 4,
    borderWidth: 0.5,
    borderColor: 'transparent',
    gap: 12,
  },
  mediaItemPlaying: {
    backgroundColor: 'rgba(108,99,255,0.1)',
    borderColor: 'rgba(108,99,255,0.2)',
  },
  thumb: {
    width: 46,
    height: 46,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  mediaMeta: { flex: 1 },
  mediaTitle: { fontSize: 14, fontWeight: '500', color: Colors.text1, marginBottom: 2 },
  mediaSub: { fontSize: 12, color: Colors.text3 },
  mediaRight: { alignItems: 'center', justifyContent: 'center', minWidth: 36 },
  duration: { fontSize: 11, color: Colors.text3 },

  playingBars: { flexDirection: 'row', alignItems: 'flex-end', height: 14, gap: 2 },
  bar: { width: 3, borderRadius: 2, backgroundColor: Colors.accent2, height: 14 },
  barAnim1: { height: 8 },
  barAnim2: { height: 14 },
  barAnim3: { height: 6 },

  serviceItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 14,
    borderRadius: Radius.sm,
    backgroundColor: Colors.bg3,
    marginBottom: 8,
    borderWidth: 0.5,
    borderColor: Colors.border,
    gap: 14,
  },
  serviceIcon: {
    width: 40,
    height: 40,
    borderRadius: 10,
    backgroundColor: 'rgba(108,99,255,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  serviceName: { flex: 1, fontSize: 15, fontWeight: '500', color: Colors.text1 },

  emptyState: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 10 },
  emptyText: { fontSize: 16, fontWeight: '500', color: Colors.text2 },
  emptySubText: { fontSize: 13, color: Colors.text3 },
});
